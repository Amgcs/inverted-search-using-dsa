#include "inverted_search.h"
int file_string(char *strarr[], char str[])     // to get files already exist from backup file
{
    int i = 0;

    str[strcspn(str, "\n")] = '\0';     //to remove new line

    char *token = strtok(str, ";");     //tokenize the each filenames

    while(token != NULL && i < 30)  
    {
        strarr[i] = malloc(strlen(token) + 1);  //to stores the each file name in array of pointers
        if(strarr[i] == NULL)
        {
            printf("Memory allocation failed\n");
            return FAILURE;
        }

        strcpy(strarr[i], token);       //storing each filename
        i++;

        token = strtok(NULL, ";");
    }

    return i;   // return number of filenames
}


int remove_duplicates(Slist **head, char *strarr[], int count)  //to remove duplicates file names
{
    for(int i = 0; i < count; i++)
    {
        compare_list_strings(head, strarr[i]);  //to compare if there is filename already exists
    }
    
    return SUCCESS;
}

int compare_list_strings(Slist **head, char *filename) 
{
    if(*head == NULL)
        return FAILURE;
    Slist *temp = *head;
    Slist *prev = NULL;

    while(temp != NULL)
    {
        if(strcmp(temp->f_name, filename) == 0)     //comparing each file names
        {
            if(prev == NULL)
            {
                *head = temp->link;
            }
            else
            {
                prev->link = temp->link;
            }

            free(temp);     //deleting filename if it already exists
            return SUCCESS;
        }

        prev = temp;
        temp = temp->link;
    }

    return FAILURE;  // not found
}

void free_strarr(char *strarr[], int count) //function to free dynamic memory
{
    for(int i = 0; i < count; i++)
    {
        free(strarr[i]);
        strarr[i] = NULL;
    }
}
