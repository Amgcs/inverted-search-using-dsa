#include"inverted_search.h"
int update_db(mnode *arr[],char *strarr[],int *arr_count)
{
    char line[200];     //for each line
    char bkup[30];      //for backup file name
    printf("Enter backup file name(.txt):\n");
    getchar();
    scanf("%s", bkup);
    FILE *fp = fopen(bkup, "r");        //opening the backup file in read mode

    if(fp == NULL)  //to check existence of file
    {
        printf("File not exist or wrong extension\n");
        return FAILURE;
    }

    char key[10];   //to get key
    fscanf(fp,"%s",key);    //reading key from file

    if(strcmp(key,"@backup--")!=0)      //comparing the key
    {
        printf("Not a backup file.\nEnter a valid backup file\n");
        return FAILURE;
    }
    fscanf(fp,"%s", line);  //reading the line that condains file names

    *arr_count=file_string(strarr,line);    //to remove already existing files

    while(fgets(line, sizeof(line), fp) != NULL)        //until the end of file
    {
        char *token = strtok(line, "#;\n");     //tokenizing each line
        
        if(token == NULL)
        continue;

        int index = atoi(token);    //to get index

        /* Get word */
        token = strtok(NULL, "#;\n");
        if(token == NULL)
            continue;

        mnode *newnode = malloc(sizeof(mnode));     //creating main node
        strcpy(newnode->words, token);              //word
        newnode->mlink = NULL;
        newnode->slink = NULL;

        /* Insert main node */
        if(arr[index] == NULL)      //if the index is NULL
        {
            arr[index] = newnode;
        }
        else    //if the index already have node
        {
            mnode *temp = arr[index];
            while(temp->mlink != NULL)  
                temp = temp->mlink;

            temp->mlink = newnode;
        }

        token = strtok(NULL, "#;\n");
        newnode->file_count = atoi(token);              // Get file count 

        snode *prev = NULL;

        for(int i = 0; i < newnode->file_count; i++)    //until it reaches the filecount
        {
            char *filename = strtok(NULL, "#;\n");      //filename
            char *count = strtok(NULL, "#;\n");         //word count

            snode *subnode = malloc(sizeof(snode));     //creating subnode
            strcpy(subnode->files, filename);           //filename
            subnode->word_count = atoi(count);          //wordcount
            subnode->slink = NULL;

            if(prev == NULL)
            {
                newnode->slink = subnode;
            }
            else
            {
                prev->slink = subnode;
            }

            prev = subnode;
        }
    }

    fclose(fp); //closing file
    printf("Database updated successfully\n");
    return SUCCESS;
}