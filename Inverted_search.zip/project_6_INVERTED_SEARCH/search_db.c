#include "inverted_search.h"
#include <ctype.h>

int search_db(char *search_word, mnode *arr[])
{
    printf("\n============================= SEARCH RESULT =============================\n\n");
    printf("\n--------------------------------------------------------------------------\n\n");

    char ch = tolower(search_word[0]);  // converting to small case
    int index = 0;

    if(isalpha(ch)) 
        index = ch - 'a';       //finding index if its alphabet
    else if(isdigit(ch))    //if its digit
        index = 26;
    else                    //if its special character
        index = 27;

    if(arr[index] == NULL)      //condition if there is no matching index in database
    {
        printf("Word '%s' not found in database.\n", search_word);
        return FAILURE;
    }

    mnode *temp = arr[index];

    while(temp != NULL)
    {
        if(strcasecmp(temp->words, search_word) == 0)   //comparing the word that present in the index
        {
            printf("%-8s %-15s %-12s %-15s %-10s\n",
                   "Index", "Word", "FileCount", "FileName", "WordCount");

            printf("--------------------------------------------------------------------------\n");

            snode *stemp = temp->slink;

            /* First file prints full row */
            if(stemp != NULL)
            {
                printf("%-8d %-15s %-12d %-15s %-10d\n",
                       index,
                       temp->words,
                       temp->file_count,
                       stemp->files,
                       stemp->word_count);

                stemp = stemp->slink;
            }

            /* Remaining files */
            while(stemp != NULL)
            {
                printf("%-8s %-15s %-12s %-15s %-10d\n",
                       "",
                       "",
                       "",
                       stemp->files,
                       stemp->word_count);

                stemp = stemp->slink;
            }

            printf("--------------------------------------------------------------------------\n");

            return SUCCESS;
        }

        temp = temp->mlink;
    }

    printf("Word '%s' not found in database.\n", search_word);      //if the word is not present in the database
    return FAILURE;
}
