#include "inverted_search.h"

int display_db(mnode *arr[])
{
    printf("\n================================ DATABASE ================================\n\n");

    printf("%-8s %-15s %-12s %-15s %-10s\n",
           "Index", "Word", "FileCount", "FileName", "WordCount");

    printf("--------------------------------------------------------------------------\n");

    for(int i = 0; i < 28; i++)
    {
        if(arr[i] != NULL)      //if there is any node presents in hashtable index
        {
            mnode *temp = arr[i];       //collects the address from that index

            while(temp != NULL)         //until the main node ends
            {
                snode *stemp = temp->slink;     //to traverse through hashtable
                if(stemp != NULL)       
                {
                    printf("%-8d %-15s %-12d %-15s %-10d\n",
                           i,
                           temp->words,
                           temp->file_count,
                           stemp->files,
                           stemp->word_count);

                    stemp = stemp->slink;
                }

                while(stemp != NULL)    // Remaining files print without repeating word/index 
                {
                    printf("%-8s %-15s %-12s %-15s %-10d\n",
                           "",
                           "",
                           "",
                           stemp->files,
                           stemp->word_count);

                    stemp = stemp->slink;
                }

                temp = temp->mlink;
            }
        }
    }

    printf("--------------------------------------------------------------------------\n");

    return SUCCESS;
}
