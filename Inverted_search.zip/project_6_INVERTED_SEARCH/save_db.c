#include"inverted_search.h"

int save_db(mnode *arr[],Slist **head)
{
    printf("Enter a backup file name...\n");
    char backup[30];        //for backup file name
    scanf("%s",backup);

    char *extn=strrchr(backup,'.');     //to check extension 
    if((extn == NULL) || (strcmp(extn,".txt")!=0))      //if its not matching extension
    {
        printf("Wrong extension\n");
        return FAILURE;
    }
    FILE *bkup=fopen(backup,"w");       //opening the backup file in write mode
    fprintf(bkup, "%s", "@backup--\n");     //writing the key into file 

    Slist *headtemp=*head;

    while(headtemp->link!=NULL)
    {
        fprintf(bkup, "%s;", headtemp->f_name);     //writing the filename into file
        headtemp = headtemp->link;
    }
    fprintf(bkup, "%s\n", headtemp->f_name);       //

    mnode *temp=NULL;
    for(int i=0;i<28;i++)       //repeating until it reaches last index
    {
        
        if(arr[i]!=NULL)    //if the index is not null
        {
            temp=arr[i];
            while(temp!=NULL)
            {
                fprintf(bkup,"#");      //# at beggining of each line to seperate it from other files
                fprintf(bkup,"%d;%s;%d",i,temp->words,temp->file_count);        //writing data of main node
                if(temp->slink!=NULL)
                {
                    snode *stemp=temp->slink;
                    while(stemp!=NULL)
                    {
                        fprintf(bkup,";%s;%d",stemp->files,stemp->word_count);      //writing data of subnode
                        stemp=stemp->slink;
                    }
                }
                fprintf(bkup,"#\n");        //writing # at end of each line
                temp=temp->mlink;
            }

        }
    }
    fclose(bkup);       //closing file
}