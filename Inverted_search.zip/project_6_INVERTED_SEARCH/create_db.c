#include"inverted_search.h"
#include<ctype.h>   // to provide tolower() function
int create_db(mnode *arr[],Slist **head)
{
    Slist *temp=*head;

    int flag=0;
    while(temp!=NULL)
    {
        char *file_name;
        file_name=temp->f_name; // file name saved inside a variable.

        FILE *fp=fopen(file_name,"r");

        if(fp==NULL)     
        {
            return FAILURE;  
        }

         
    char word[50];  //to store each words
    while (fscanf(fp, "%s", word) != EOF)
        {
            flag=0;
            for(int k = 0; word[k]; k++)    //to convert all letters to lower
            {
                word[k] = tolower(word[k]);
            }

            char ch =word[0];

            mnode *temp_m=NULL;
            int index=0;
            if(isalpha(ch)) //to check if the words start with alphabet
            {
                index = ch - 'a';
            }
             else if(isdigit(ch))   //to check digit or not
            {
                index = 26;
            }
            else    //for special characters
            {
                index = 27;
            }
                temp_m = arr[index];    //to traverse through hash table
                if(temp_m==NULL)
                {
                    mnode *newnode=malloc(sizeof(mnode));   //creating main node
                    newnode->mlink=NULL;
                    strcpy(newnode->words,word);    //saving each word in each main node
                    newnode->file_count=1;          //storing file count
                    arr[index]=newnode;         

                    snode *subnode=malloc(sizeof(snode));  //creating subnode
                    strcpy(subnode->files,file_name);       //copying file name
                    subnode->word_count=1;                  //string word count
                    arr[index]->slink=subnode;
                    subnode->slink=NULL; 
                }
                else        //if hash table index is not
                {
                    mnode *prev = NULL;

                    /* Traverse entire main node chain */
                    while(temp_m != NULL)
                    {
                        if(strcasecmp(temp_m->words, word) == 0)        //to check the word already present or not
                        {
                            flag = 1;
                            snode *temp_s = temp_m->slink;
                            snode *prev_s = NULL;

                            /* Traverse entire subnode chain */
                            while(temp_s != NULL)
                            {
                                if(strcmp(temp_s->files, file_name) == 0)
                                {
                                    temp_s->word_count++;   // duplicate word in same file
                                    break;
                                }

                                prev_s = temp_s;
                                temp_s = temp_s->slink;
                            }

                            if(temp_s == NULL)
                            {
                                snode *subnode = malloc(sizeof(snode));
                                strcpy(subnode->files, file_name);
                                subnode->word_count = 1;
                                subnode->slink = NULL;

                                prev_s->slink = subnode;
                                temp_m->file_count++;
                            }

                            break;   // stop searching main list
                        }

                        prev = temp_m;
                        temp_m = temp_m->mlink;
                    }

                    if(flag == 0)   //if the word is not found in list then create new one
                    {
                        mnode *newnode = malloc(sizeof(mnode));
                        strcpy(newnode->words, word);
                        newnode->file_count = 1;
                        newnode->mlink = NULL;
                        newnode->slink = NULL;

                        prev->mlink = newnode;

                        snode *subnode = malloc(sizeof(snode));
                        strcpy(subnode->files, file_name);
                        subnode->word_count = 1;
                        subnode->slink = NULL;

                        newnode->slink = subnode;
                    }
                }
        }
            
        
            fclose(fp);
            temp=temp->link;
        }

        return SUCCESS;
}