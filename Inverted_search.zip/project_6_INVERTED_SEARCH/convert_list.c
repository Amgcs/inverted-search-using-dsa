#include"inverted_search.h"
 
int string_to_list(char *filename,Slist **head)
{
    FILE *fp=fopen(filename,"r");       //opening the file in read mode
    if(fp==NULL)    
    {
        printf("%s not existing!\n",filename);
        return FAILURE;
    }
 
    fseek(fp, 0, SEEK_END);     //to check if the file is empty or not
    if (ftell(fp) == 0)
    {
        printf("%s is empty\n",filename);
        return FAILURE;
    }
    rewind(fp); //rewind to starting position in file

    Slist *temp=*head;

    while(temp!=NULL)   //to check duplicates 
    {
        if(strcmp(temp->f_name,filename)==0)    //to avoid multiple files with same name
            {
                printf("%s already existing...\n",filename);
                fclose(fp);
                return FAILURE;
            }
            temp=temp->link;
    }

    Slist *newnode=malloc(sizeof(Slist));       //creating new node to store filename
    if(!newnode)
    {
        fclose(fp);
        return FAILURE;
    }
    newnode->link=NULL; 
    strcpy(newnode->f_name,filename);       //to copy string to node

    if(*head==NULL)
    {
        *head=newnode;
        fclose(fp);
        return SUCCESS;
    }
    else    //insert at first
    {
        newnode->link=*head;
        *head=newnode;  
    }

    fclose(fp);
    return SUCCESS;

}
 
int validation(int argc,char *argv[],Slist **head)  //validation function
{
    if(argc < 2)    //if there is only 2 arguments available
    {
        return FAILURE;
    }
    
    int i=1;
    while(i<argc)
    {
        char *extn=strrchr(argv[i],'.');
        if((extn==NULL) || (strcmp(extn,".txt")!=0))    // if the extension is wrong type
        {
            printf("File %d has wrong extension\n",i);
            i++;
            continue;
        }
            //call string to linked list function here
            char *filename=argv[i];
            string_to_list(filename,head);  //to convert filenames to linked list
        i++;
    }
    return SUCCESS;
}