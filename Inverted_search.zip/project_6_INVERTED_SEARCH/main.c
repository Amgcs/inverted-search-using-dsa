/*
Name: AMEGH C S
Reg NO: 25026_046
Project: INVERTED SEARCH
*/

#include"inverted_search.h" //header file containing function prototype and macros

int main(int argc,char *argv[])     //collecting command line arguments
{

    Slist *head=NULL;   //set head to null for linked list 
    mnode *arr[HASH_SIZE]={NULL};   //initializing hash table with NULL
    char *strarr[30]={NULL};    //array of pointers to store files in backup file
    int arr_count=0;    //to collect file counts present in backup file
    if(validation(argc,argv,&head)) //validation for files names and extension
    {
        printf("Provide proper files\n");
        return FAILURE;
    }
    print_list(head);   //for showing current files
    int flag=0;     //flag to create database
    int uflag=0;    //flag for update database


    printf("---------------------------------------------------\n");
    printf("\t\tINVERTED SEARCH\n");
    printf("---------------------------------------------------\n");
    while(1)
    {
        printf("Select an option:\n 1. Create Database\n 2. Search Database\n 3. Display Database\n 4. Save Database\n 5. Update Database\n 6. Exit\n\n");
        int opt;
        scanf("%d",&opt);
        switch(opt)
        {
            case 1:
                printf("Selected : Create Database\n"); 
                if(flag==0)
                {
                    create_db(arr,&head);   //calling create database
                    flag=1; 
                    printf("\nDatabase created successfully\n");
                    break;
                }
                else
                {
                    printf("\nDatabase already created\n");
                    break;
                }
            case 2: 
            printf("Selected : Search Database\n"); 
            if(flag==1 || uflag==1) //only if create or update happens
            {
                getchar();
                printf("Enter a word to search : \n");
                char search_word[50];       //word for search
                scanf("%s",search_word);
                search_db(search_word,arr);     //calling searching function
            }
            else
                printf("\nEmpty Database\n");
                break;
            case 3: 
                    printf("Selected : Display Database\n"); 
                    if(flag==1 || uflag==1)     //only if creation or updation happens
                    {
                        display_db(arr);    //calling display function
                    }
                    else
                        printf("\nEmpty Database\n");
                break;
            case 4: 
                    printf("Selected : Save Database\n"); 
                    if(uflag==1)
                    {
                        for(int i=0;i<arr_count;i++)
                        {
                            insert_at_first(&head,strarr[i]);       //to update linked list for save current file names in backup file
                        }
                        free_strarr(strarr,arr_count);
                        printf("Exiting here\n");
                    }
                    if(flag==1 || uflag==1) //only if creation or updation happens
                    {
                        if(save_db(arr,&head))     //calling save function
                        {
                            break;
                        }
                        printf("\nDatabase saved successfully\n");
                    }
                    else
                    printf("\nEmpty Database\n");
                break;
            case 5: 
                    printf("Selected : Update Database\n"); 
                if(flag==0 && uflag==0)     //happens only for first time
                {
                    if(update_db(arr,strarr,&arr_count))        //calling updation function
                    {
                        break;
                    }
                    remove_duplicates(&head,strarr,arr_count);      //function to remove already exiting files from linked list
                    uflag=1;
                    break;
                }
                else
                {
                    printf("\nUpdate not possible now\n");
                    break;
                }
            case 6:printf("\nExiting Database....\n");
            printf("\n---------------------------------------------------\n");
                    return FAILURE;
                break;
                default:
                    printf("\nEnter valid option\n");
        }
        printf("---------------------------------------------------\n");
    }
    return 0;    
}