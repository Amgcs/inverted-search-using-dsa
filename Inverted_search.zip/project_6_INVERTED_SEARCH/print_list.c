#include "inverted_search.h"

void print_list(Slist *temp)    //function to print list of files names passed through CLA
{
    if (temp == NULL)
    {
        printf("List is empty\n");
        return;
    }

    printf("Available files are: \n");
    while(temp!=NULL)
    {
        printf("%s\n",temp->f_name);
        temp=temp->link;
    }
} 