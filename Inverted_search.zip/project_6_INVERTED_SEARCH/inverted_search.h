#ifndef SEARCH_H
#define SEARCH_H

#include<stdio.h>   //for standard i/o
#include<stdlib.h>      //for standard library functions
#include<string.h>      //for string functions

#define SUCCESS 0       
#define FAILURE 1

#define MAX_FILENAME 30
#define MAX_WORD     50
#define HASH_SIZE    28


typedef struct list     //structure for save filenames
{
    char f_name[MAX_FILENAME];
    struct list *link;
}Slist;

typedef struct s_node       //structure for subnode
{
    char files[MAX_FILENAME];
    int word_count;
    struct s_node *slink;
}snode;

typedef struct m_node       //structure for main node
{
    char words[MAX_WORD];
    int file_count;
    struct m_node *mlink;
    struct s_node *slink;
}mnode;

int validation(int argc,char *argv[],Slist **head);

int string_to_list(char *filename,Slist **head);

void print_list(Slist *temp);   

int create_db(mnode *arr[],Slist **head);

int display_db(mnode *arr[]);

int search_db(char *search_word,mnode *arr[]);

int save_db(mnode *arr[],Slist **head);

int update_db(mnode *arr[],char *strarr[],int *arr_count);

int file_string(char *strarr[],char str[]);

int compare_list_strings( Slist **head,char *arr);

int remove_duplicates(Slist **head,char *str[],int count);

int insert_at_first(Slist **head,char arr[]);

void free_strarr(char *strarr[], int count);

#endif